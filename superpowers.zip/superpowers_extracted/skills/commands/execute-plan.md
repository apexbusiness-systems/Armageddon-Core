Use your Executing-Plans skill.
