Use your brainstorming skill.
