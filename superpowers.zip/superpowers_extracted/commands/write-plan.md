---
description: Create detailed implementation plan with bite-sized tasks
---

Use the writing-plans skill exactly as written
