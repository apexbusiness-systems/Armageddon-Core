---
description: Interactive design refinement using Socratic method
---

Use and follow the brainstorming skill exactly as written
